import { db } from "../_utils/firebase";
import { collection, getDocs, addDoc, query } from "firebase/firestore";

async function getItems(userId) {
    try {
        const items = [];
        const q = query(collection(db, 'users', userId, 'items'));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
            items.push(doc);
        });

        return items;
    } catch (error) {
        console.error('Error getting user items', error);
    }
};

async function addItem(userId, item) {
    try {
        const docRef = await addDoc(collection(db, "users", userId, "items"), item);
        return docRef.id;
    } catch (error) {
        console.error("Problem adding item", error);
    }
};